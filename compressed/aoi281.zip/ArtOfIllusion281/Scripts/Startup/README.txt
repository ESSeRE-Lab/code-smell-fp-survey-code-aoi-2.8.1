This folder is for Startup scripts.  Any Beanshell scripts placed in this folder will be executed when the application is launched.
