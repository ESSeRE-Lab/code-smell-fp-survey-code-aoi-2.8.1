This folder is for Object scripts.  Any Beanshell scripts placed in this folder will be presented as options for the "Create Scripted Object" command.
