This folder is for Tool scripts.  Any Beanshell scripts placed in this folder or subfolders will appear in the Tools menu.
